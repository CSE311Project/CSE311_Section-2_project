<? php
$server = "localhost" ; 
$username = "root" ;
$password = "";
$dbname = "propel_ecommerce" ;

$conn = mysqli_connect($server , $usernam ,$password, $dbname);

$sql = "INSERT INTO" 'customer_orders'
('order_id', 'user_id', 'product_id')